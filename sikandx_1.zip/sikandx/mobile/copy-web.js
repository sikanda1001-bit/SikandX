// Copies ../web into ./www so Capacitor can bundle it.
const fs = require("fs"), path = require("path");
const src = path.join(__dirname, "..", "web"), dst = path.join(__dirname, "www");
fs.rmSync(dst, { recursive: true, force: true });
fs.cpSync(src, dst, { recursive: true });
console.log("Copied web app to", dst);
