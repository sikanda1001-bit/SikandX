import os, sys, tempfile, time
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ["SIKANDX_DATA"] = tempfile.mkdtemp()
from core.data import make_sample_m1
from core.config import Settings
from core.backtest import run_backtest
t = time.time()
for seed in (11, 12, 13, 14):
    r = run_backtest(make_sample_m1(8000, seed=seed), Settings())
    r.pop("curve"); r.pop("bars")
    print(seed, r)
print("secs", round(time.time() - t, 1))
