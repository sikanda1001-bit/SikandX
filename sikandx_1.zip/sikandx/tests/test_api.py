import os, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ["SIKANDX_DATA"] = tempfile.mkdtemp()
from core.config import Settings, Store
from core.engine import Engine
from server import create_app
from brokers.paper import PaperBroker

cfg = Settings(); eng = Engine(cfg, Store())
app = create_app(eng, token="secret123", start_engine=False)
c = app.test_client()
H = {"Authorization": "Bearer secret123"}

def check(name, cond):
    print(("PASS " if cond else "FAIL ") + name)
    assert cond, name

check("unauthenticated state rejected", c.get("/api/state").status_code == 401)
check("wrong token rejected", c.get("/api/state", headers={"Authorization": "Bearer x"}).status_code == 401)
check("ping public", c.get("/api/ping").status_code == 200)
check("web index served", b"SikandX" in c.get("/").data or c.get("/").status_code in (200, 404))
for _ in range(3): eng.cycle()
s = c.get("/api/state", headers=H).get_json()
check("state ok", s["ok"] and s["account"]["equity"] == 100.0)
check("synthetic feed labelled", "Synthetic" in s["broker"]["feed"])
r = c.post("/api/command", headers=H, json={"text": "buy"}).get_json()["reply"]; print("   buy ->", r)
check("manual buy opened", len(eng.broker.positions()) == 1)
check("lots honest (min lot)", eng.broker.positions()[0].lots >= 0.01)
r = c.post("/api/command", headers=H, json={"text": "buy 9"}).get_json()["reply"]; print("   buy 9 ->", r)
check("lots capped by max_lots", max(p.lots for p in eng.broker.positions()) <= cfg.max_lots)
print("   close all ->", c.post("/api/close-all", headers=H).get_json()["reply"])
check("closed", len(eng.broker.positions()) == 0)

# target enforcement: push equity over target with a winning fake
eng.set_settings({"equity_target": 100.5})
eng.broker.balance = 101.0
eng.cycle()
check("halted at target", eng.halted)
check("halt persisted", Store().load()["halted"] is True)
print("   buy while halted ->", c.post("/api/command", headers=H, json={"text": "buy"}).get_json()["reply"])
check("no entry while halted", len(eng.broker.positions()) == 0)
print("   resume w/o raising target ->", c.post("/api/resume", headers=H, json={}).get_json()["reply"])
check("resume refused below target", eng.halted)
print("   resume w/ target ->", c.post("/api/resume", headers=H, json={"target": 500}).get_json()["reply"])
check("resumed", not eng.halted and cfg.equity_target == 500)

# restart restores halt + settings
eng.broker.balance = 600.0; eng.cycle()
cfg2 = Settings(); eng2 = Engine(cfg2, Store())
check("restart restores halt", eng2.halted)

# live gate: fake a live broker
class FakeLive(PaperBroker):
    kind = "paper"; is_demo = False; label = "Fake live"
eng.halted = False; eng.paused = False; cfg.equity_target = 1e6
eng.broker = FakeLive(100, 100, 0.35); eng.feed.step(); eng.broker.mark(eng.feed.step()); eng.cycle()
r = eng.command("buy"); print("   live buy ->", r)
check("live blocked before confirm", len(eng.broker.positions()) == 0)
eng.command("confirm live"); r = eng.command("buy"); print("   live buy after confirm ->", r)
check("live allowed after confirm", len(eng.broker.positions()) == 1)
eng.live_confirmed = False
check("close never blocked on live", "Closed 1" in eng.command("close all"))

# auto refuses without gate; position limit
eng.broker = PaperBroker(100, 100, 0.35); eng.broker.mark(eng.feed.step()); eng.cycle()
eng.set_auto(True)
for _ in range(5): eng.cycle()
print("   auto trades after 5 cycles:", len(eng.broker.positions()), "| gate:", eng.describe_signal())
check("bad commands handled", "number" in eng.command("set target").lower())
check("backtest endpoint", c.post("/api/backtest", headers=H, json={"bars": 1500}).get_json()["ok"])
check("chart endpoint", len(c.get("/api/chart", headers=H).get_json()["candles"]) > 50)
print("ALL PASSED")
