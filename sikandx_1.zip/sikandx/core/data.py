"""Candle sources: synthetic generator (demo/backtest), CSV loader, resampling."""
import numpy as np
import pandas as pd


class SampleGen:
    """Regime-switching gold-like random walk: ranges, then impulses, then trends."""

    def __init__(self, seed=7, price=2350.0):
        self.rng = np.random.default_rng(seed)
        self.p = price
        self.left = 0
        self.drift = 0.0
        self.vol = 0.2
        self.kick = 0.0

    def next(self) -> dict:
        r = self.rng
        if self.left <= 0:
            reg = str(r.choice(["range", "up", "down", "range"]))
            self.left = int(r.integers(15, 70))
            self.drift = {"range": 0.0, "up": 0.10, "down": -0.10}[reg]
            self.vol = 0.16 if reg == "range" else 0.30
            self.kick = 0.0 if reg == "range" else (1.0 if reg == "up" else -1.0) * float(r.uniform(1.0, 1.8))
        self.left -= 1
        o = self.p
        c = o + self.drift + float(r.normal(0, self.vol)) + self.kick
        self.kick = 0.0
        hi = max(o, c) + abs(float(r.normal(0, self.vol * 0.6)))
        lo = min(o, c) - abs(float(r.normal(0, self.vol * 0.6)))
        self.p = c
        return dict(open=o, high=hi, low=lo, close=c)


def make_sample_m1(n=1500, seed=7, price=2350.0) -> pd.DataFrame:
    g = SampleGen(seed, price)
    rows = [g.next() for _ in range(n)]
    end = pd.Timestamp.now().floor("15min") - pd.Timedelta(minutes=1)
    df = pd.DataFrame(rows)
    df.insert(0, "time", pd.date_range(end=end, periods=n, freq="1min"))
    return df


def resample(m1: pd.DataFrame, rule: str) -> pd.DataFrame:
    d = m1.set_index("time")[["open", "high", "low", "close"]]
    out = d.resample(rule).agg({"open": "first", "high": "max", "low": "min", "close": "last"}).dropna()
    return out.reset_index()


def load_csv(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df.columns = [c.lower().strip() for c in df.columns]
    if "time" not in df.columns:
        for c in ("date", "datetime", "timestamp"):
            if c in df.columns:
                df = df.rename(columns={c: "time"})
                break
    df["time"] = pd.to_datetime(df["time"])
    return df[["time", "open", "high", "low", "close"]].sort_values("time").reset_index(drop=True)


class SampleFeed:
    """Synthetic 'live' feed for demo mode. One new M1 bar per engine cycle."""
    label = "Synthetic demo feed"

    def __init__(self, seed=7, n=1200):
        self.gen = SampleGen(seed)
        rows = [self.gen.next() for _ in range(n)]
        start = pd.Timestamp.now().floor("min") - pd.Timedelta(minutes=n)
        self.df = pd.DataFrame(rows)
        self.df.insert(0, "time", pd.date_range(start=start, periods=n, freq="1min"))

    def step(self) -> dict:
        bar = self.gen.next()
        t = self.df["time"].iloc[-1] + pd.Timedelta(minutes=1)
        self.df.loc[len(self.df)] = [t, bar["open"], bar["high"], bar["low"], bar["close"]]
        if len(self.df) > 3000:
            self.df = self.df.tail(2000).reset_index(drop=True)
        return bar

    def frames(self):
        m1 = self.df
        return (m1.tail(400).reset_index(drop=True),
                resample(m1, "5min").tail(400).reset_index(drop=True),
                resample(m1, "15min").tail(400).reset_index(drop=True))
