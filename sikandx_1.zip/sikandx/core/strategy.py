"""SikandX strategy: supply/demand + BOS + reversals + trendlines across M1/M5/M15.

analyze() runs once per timeframe; bias() builds the supply/demand meter from it;
signal() scores M5, filters with M15, refines with M1, and computes SL/TP.
"""
import pandas as pd
from .zones import detect_zones, zones_near_price, nearest_opposing_zone, atr
from .structure import structure_state, reversal_signal, detect_trendlines

WEIGHTS = {"M1": 0.20, "M5": 0.30, "M15": 0.50}


def analyze(df: pd.DataFrame, cfg):
    if df is None or len(df) < 40:
        return None
    i = len(df) - 1
    price = float(df["close"].iloc[i])
    a = float(atr(df).bfill().fillna(0.3).iloc[i])
    zones = detect_zones(df, cfg)
    tol = a * cfg.zone_touch_atr * 2
    return dict(
        df=df, i=i, price=price, atr=max(a, 1e-6), zones=zones, tol=tol,
        near=zones_near_price(zones, price, tol),
        state=structure_state(df, cfg.swing_window, cfg.bos_confirm_bars),
        rev=reversal_signal(df, i, cfg.wick_ratio),
        lines=detect_trendlines(df, cfg, a))


def tf_bias(an) -> dict:
    """Supply/demand meter for one timeframe, -100 (supply) .. +100 (demand)."""
    if an is None:
        return dict(score=0, trend="range", label="No data")
    p, a = an["price"], an["atr"]
    d = s = 0.0
    for z in an["zones"]:
        if z["type"] == "demand" and z["bottom"] <= p + an["tol"]:
            d += z["score"] / (1 + max(0.0, p - z["top"]) / a)
        elif z["type"] == "supply" and z["top"] >= p - an["tol"]:
            s += z["score"] / (1 + max(0.0, z["bottom"] - p) / a)
    raw = (d - s) / (d + s) * 70 if (d + s) > 0 else 0.0
    t = an["state"]["trend"]
    raw += 30 if t == "up" else (-30 if t == "down" else 0)
    sc = int(max(-100, min(100, round(raw))))
    return dict(score=sc, trend=t, label=_label(sc))


def _label(s):
    return ("Strong demand" if s >= 50 else "Demand" if s >= 20 else
            "Strong supply" if s <= -50 else "Supply" if s <= -20 else "Balanced")


def combined_bias(an: dict) -> dict:
    out = {tf: tf_bias(an.get(tf)) for tf in ("M1", "M5", "M15")}
    tot = int(round(sum(out[tf]["score"] * w for tf, w in WEIGHTS.items())))
    out["total"] = dict(score=tot, label=_label(tot))
    return out


def score_frame(an, cfg, bias_score: int) -> dict:
    i, st, rev = an["i"], an["state"], an["rev"]
    near, tol = an["near"], an["tol"]
    in_dem = any(z["type"] == "demand" for z in near)
    in_sup = any(z["type"] == "supply" for z in near)
    recent = lambda d: st["last_bos_dir"] == d and st["last_bos_index"] is not None and i - st["last_bos_index"] <= 10
    sup_b = any(L["side"] == "support" and abs(L["distance"]) <= tol * 2 and not L["broke"] for L in an["lines"])
    res_r = any(L["side"] == "resistance" and abs(L["distance"]) <= tol * 2 and not L["broke"] for L in an["lines"])
    bos_up, bos_dn = recent("up"), recent("down")

    buy = sell = 0
    why = []
    if in_dem: buy += 25; why.append("In demand zone")
    if in_sup: sell += 25; why.append("In supply zone")
    if rev["bullish"]: buy += 20; why.append(f"Bullish {rev['kind']}")
    if rev["bearish"]: sell += 20; why.append(f"Bearish {rev['kind']}")
    if bos_up: buy += 15; why.append("Break of structure up")
    if bos_dn: sell += 15; why.append("Break of structure down")
    if st["trend"] == "up": buy += 8
    if st["trend"] == "down": sell += 8
    if sup_b: buy += 10; why.append("Trendline support bounce")
    if res_r: sell += 10; why.append("Trendline resistance rejection")
    if in_sup and rev["bearish"]: sell += 12; why.append("Resistance reversal toward demand")
    if in_dem and rev["bullish"]: buy += 12; why.append("Demand bounce")
    if bias_score >= 20: buy += 8
    elif bias_score <= -20: sell += 8

    side, score = None, 0
    if buy >= cfg.min_score and buy > sell + 5: side, score = "buy", buy
    elif sell >= cfg.min_score and sell > buy + 5: side, score = "sell", sell
    gate = dict(
        zone=(in_dem if side == "buy" else in_sup) if side else False,
        confirm=((bos_up or sup_b) if side == "buy" else (bos_dn or res_r)) if side else False)
    return dict(side=side, score=int(min(100, score)), reasons=why, gate=gate)


def signal(m1, m5, m15, cfg) -> dict:
    an = {"M1": analyze(m1, cfg), "M5": analyze(m5, cfg), "M15": analyze(m15, cfg)}
    bias = combined_bias(an)
    base = dict(side=None, score=0, reasons=[], gate=dict(zone=False, confirm=False),
                bias=bias, price=None, atr=None, sl=None, tp=None, an=an)
    a5 = an["M5"]
    if a5 is None:
        base["reasons"] = ["Not enough candle history"]
        return base
    base["price"], base["atr"] = a5["price"], a5["atr"]
    s5 = score_frame(a5, cfg, bias["M5"]["score"])
    base.update(reasons=s5["reasons"], gate=s5["gate"])
    if s5["side"] is None:
        return base

    side = s5["side"]
    m15b = bias["M15"]
    if side == "buy" and (m15b["score"] <= -35 or m15b["trend"] == "down"):
        base["reasons"] = s5["reasons"] + ["Vetoed: M15 supply or downtrend"]; return base
    if side == "sell" and (m15b["score"] >= 35 or m15b["trend"] == "up"):
        base["reasons"] = s5["reasons"] + ["Vetoed: M15 demand or uptrend"]; return base

    score = s5["score"]
    if an["M1"] is not None:
        t1 = score_frame(an["M1"], cfg, bias["M1"]["score"])
        if t1["side"] == side:
            score = min(100, score + 8); s5["reasons"].append("M1 trigger agrees")
        elif t1["side"] is not None:
            base["reasons"] = s5["reasons"] + ["Vetoed: M1 points the other way"]; return base

    price, a, zones = a5["price"], a5["atr"], a5["zones"]
    if side == "buy":
        opp = nearest_opposing_zone(zones, price, "buy")
        tp = float(opp["bottom"]) if opp else price + a * 3.0
        dem = [z for z in a5["near"] if z["type"] == "demand"]
        sl = min(z["bottom"] for z in dem) - cfg.stop_buffer if dem else price - a * cfg.sl_atr_mult
        if tp <= price: tp = price + a * 2.0
        if sl >= price: sl = price - a * cfg.sl_atr_mult
        sl = min(sl, price - 0.5 * a)
    else:
        opp = nearest_opposing_zone(zones, price, "sell")
        tp = float(opp["top"]) if opp else price - a * 3.0
        sup = [z for z in a5["near"] if z["type"] == "supply"]
        sl = max(z["top"] for z in sup) + cfg.stop_buffer if sup else price + a * cfg.sl_atr_mult
        if tp >= price: tp = price - a * 2.0
        if sl <= price: sl = price + a * cfg.sl_atr_mult
        sl = max(sl, price + 0.5 * a)

    risk = abs(price - sl)
    if risk > cfg.max_sl_atr * a:
        base["reasons"] = s5["reasons"] + [f"Rejected: stop is wider than {cfg.max_sl_atr:g} ATR"]; return base
    if abs(tp - price) / risk < cfg.min_rr:
        need = risk * cfg.min_rr
        tp = price + need if side == "buy" else price - need

    base.update(side=side, score=int(score), reasons=s5["reasons"], sl=float(sl), tp=float(tp))
    return base


def auto_gate(sig: dict, cfg):
    """Autonomous entries need: scored zone + (BOS or trendline) + score >= minimum. No override."""
    if not sig.get("side"):
        return False, "No qualifying setup."
    if sig["score"] < cfg.min_score:
        return False, f"Score {sig['score']} is below the minimum {cfg.min_score}."
    g = sig["gate"]
    if not g["zone"]:
        return False, "Not inside a scored zone."
    if not g["confirm"]:
        return False, "No break of structure or trendline confirmation."
    return True, "Gate passed."


def compact(sig: dict) -> dict:
    r = lambda v: round(float(v), 2) if v is not None else None
    return dict(side=sig["side"], score=sig["score"], reasons=sig["reasons"][:7], gate=sig["gate"],
                price=r(sig["price"]), atr=r(sig["atr"]), sl=r(sig["sl"]), tp=r(sig["tp"]),
                bias={k: ({"score": v["score"], "label": v["label"]}) for k, v in sig["bias"].items()})
