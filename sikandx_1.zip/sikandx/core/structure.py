"""Swings, break of structure / change of character, reversal candles, trendlines."""
import pandas as pd


def swings(df: pd.DataFrame, w: int):
    h, l = df["high"].to_numpy(float), df["low"].to_numpy(float)
    highs, lows = [], []
    for i in range(w, len(df) - w):
        if h[i] == h[i - w:i + w + 1].max():
            highs.append((i, float(h[i])))
        if l[i] == l[i - w:i + w + 1].min():
            lows.append((i, float(l[i])))
    return highs, lows


def structure_state(df: pd.DataFrame, w: int, confirm: int) -> dict:
    """BOS = `confirm` consecutive closes beyond the latest confirmed swing. CHoCH = BOS against the prior trend."""
    c = df["close"].to_numpy(float)
    highs, lows = swings(df, w)
    trend, last_dir, last_idx, choch = "range", None, None, False
    hi_i = lo_i = -1
    sh = sl = None
    run_up = run_dn = 0
    for i in range(len(df)):
        while hi_i + 1 < len(highs) and highs[hi_i + 1][0] + w <= i:
            hi_i += 1
            sh = highs[hi_i][1]
            run_up = 0
        while lo_i + 1 < len(lows) and lows[lo_i + 1][0] + w <= i:
            lo_i += 1
            sl = lows[lo_i][1]
            run_dn = 0
        if sh is not None and c[i] > sh:
            run_up += 1
            if run_up == confirm:
                choch = trend == "down"
                trend, last_dir, last_idx = "up", "up", i
                sh = None
        elif sh is not None:
            run_up = 0
        if sl is not None and c[i] < sl:
            run_dn += 1
            if run_dn == confirm:
                choch = trend == "up"
                trend, last_dir, last_idx = "down", "down", i
                sl = None
        elif sl is not None:
            run_dn = 0
    return dict(trend=trend, last_bos_dir=last_dir, last_bos_index=last_idx, choch=choch)


def reversal_signal(df: pd.DataFrame, i: int, wick_ratio: float) -> dict:
    out = dict(bullish=False, bearish=False, kind="")
    if i < 2:
        return out
    o, h, l, c = (df[k].to_numpy(float) for k in ("open", "high", "low", "close"))
    rng = max(h[i] - l[i], 1e-9)
    lower = min(o[i], c[i]) - l[i]
    upper = h[i] - max(o[i], c[i])
    if lower / rng >= wick_ratio and c[i] >= l[i] + rng * 0.5:
        out.update(bullish=True, kind="pinbar")
    if upper / rng >= wick_ratio and c[i] <= h[i] - rng * 0.5:
        out.update(bearish=True, kind="pinbar")
    if c[i - 1] < o[i - 1] and c[i] > o[i] and c[i] >= o[i - 1] and o[i] <= c[i - 1]:
        out.update(bullish=True, kind="engulfing")
    if c[i - 1] > o[i - 1] and c[i] < o[i] and c[i] <= o[i - 1] and o[i] >= c[i - 1]:
        out.update(bearish=True, kind="engulfing")
    return out


def _best_line(points, tol, min_touches, rising):
    best = None
    for a in range(len(points)):
        for b in range(a + 1, len(points)):
            (x1, y1), (x2, y2) = points[a], points[b]
            if x2 == x1:
                continue
            m = (y2 - y1) / (x2 - x1)
            if (rising and m < 0) or ((not rising) and m > 0):
                continue
            touches = sum(1 for (x, y) in points if abs(y - (y1 + m * (x - x1))) <= tol)
            if touches >= min_touches and (best is None or touches > best[0]):
                best = (touches, m, y1 - m * x1)
    return best


def detect_trendlines(df: pd.DataFrame, cfg, a: float) -> list:
    n = len(df)
    start = max(0, n - cfg.tl_lookback)
    highs, lows = swings(df.iloc[start:].reset_index(drop=True), cfg.swing_window)
    tol = a * cfg.tl_tol_atr
    price = float(df["close"].iloc[-1])
    x_last = n - 1 - start
    out = []
    for side, pts, rising in (("support", lows, True), ("resistance", highs, False)):
        best = _best_line(pts, tol, cfg.tl_min_touches, rising)
        if not best:
            continue
        touches, m, b = best
        val = m * x_last + b
        broke = price < val - tol if side == "support" else price > val + tol
        out.append(dict(side=side, touches=touches, value=float(val),
                        distance=float(price - val), broke=bool(broke)))
    return out
