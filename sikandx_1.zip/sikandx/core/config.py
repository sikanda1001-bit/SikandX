"""Settings + persistence. Secrets (broker passwords, API token) are never stored here."""
import json, os, tempfile
from dataclasses import dataclass

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.environ.get("SIKANDX_DATA", os.path.join(ROOT, "data"))

# user-editable keys -> (type, min, max)
EDITABLE = {
    "equity_target": (float, 1, 1e9),
    "max_positions": (int, 1, 20),
    "min_score": (int, 0, 100),
    "risk_pct": (float, 0.1, 5.0),
    "daily_loss_pct": (float, 0, 50),
    "max_lots": (float, 0.01, 50),
    "paper_balance": (float, 10, 1e9),
    "loop_seconds": (int, 5, 300),
}


@dataclass
class Settings:
    symbol: str = "XAUUSD"
    symbol_variants: tuple = ("XAUUSD", "XAUUSDm", "XAUUSD+", "GOLD", "XAUUSD.PRO")

    # account / protection
    paper_balance: float = 100.0
    equity_target: float = 300.0
    daily_loss_pct: float = 5.0        # halt if equity falls this % below the day's start (0 = off)
    max_positions: int = 5
    max_lots: float = 0.5
    loop_seconds: int = 15

    # entries
    min_score: int = 45
    risk_pct: float = 1.0
    max_risk_overshoot: float = 2.0    # skip trade if the min lot would risk > 2x intended
    sl_atr_mult: float = 1.5
    max_sl_atr: float = 4.0            # reject setups whose stop is wider than this many ATR
    min_rr: float = 1.5
    stop_buffer: float = 0.30
    entry_gap_atr: float = 0.5         # same-side entries must be this far apart
    cooldown_seconds: int = 60
    spread: float = 0.35               # paper/backtest spread in dollars
    contract_size: float = 100.0

    # zones / structure
    swing_window: int = 5
    base_max_bars: int = 8
    base_bar_atr: float = 0.8
    base_total_atr: float = 2.0
    impulse_atr: float = 1.2
    zone_expiry_bars: int = 300
    zone_touch_atr: float = 0.25
    bos_confirm_bars: int = 2
    wick_ratio: float = 0.45
    tl_min_touches: int = 3
    tl_tol_atr: float = 0.35
    tl_lookback: int = 120

    def update(self, d: dict) -> list:
        changed = []
        for k, v in (d or {}).items():
            if k not in EDITABLE:
                continue
            typ, lo, hi = EDITABLE[k]
            try:
                val = typ(float(v))
            except (TypeError, ValueError):
                continue
            val = max(lo, min(hi, val))
            if getattr(self, k) != val:
                setattr(self, k, val)
                changed.append(k)
        return changed

    def public(self) -> dict:
        d = {k: getattr(self, k) for k in EDITABLE}
        d["symbol"] = self.symbol
        return d


class Store:
    """Small JSON file so a restart cannot silently drop the target or halt state."""

    def __init__(self, path=None):
        os.makedirs(DATA_DIR, exist_ok=True)
        self.path = path or os.path.join(DATA_DIR, "state.json")

    def load(self) -> dict:
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}

    def save(self, blob: dict):
        fd, tmp = tempfile.mkstemp(dir=os.path.dirname(self.path))
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(blob, f)
        os.replace(tmp, self.path)
