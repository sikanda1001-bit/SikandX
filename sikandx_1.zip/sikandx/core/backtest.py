"""Backtest: replays M1 candles through the same strategy, sizing and protection rules as live."""
import copy
import pandas as pd
from .config import Settings
from .data import make_sample_m1, resample, load_csv
from . import strategy as S
from .risk import lots_for
from brokers.paper import PaperBroker


def run_backtest(m1: pd.DataFrame, cfg: Settings, balance=None, target=None, warmup=450, step=5):
    cfg = copy.copy(cfg)
    balance = float(balance or cfg.paper_balance)
    target = float(target or cfg.equity_target)
    b = PaperBroker(balance, cfg.contract_size, cfg.spread)
    spec = b.spec()
    halted, curve, last_entry = False, [], {}
    for i in range(warmup, len(m1)):
        row = m1.iloc[i]
        bar = dict(open=row.open, high=row.high, low=row.low, close=row.close)
        b.mark(bar)
        eq = b.account().equity
        if not halted and eq >= target:
            b.close_all()
            halted = True
        if (i - warmup) % step == 0:
            curve.append(eq)
        if halted:
            continue
        if row["time"].minute % 5 != 4:                 # decide only when an M5 candle has just closed
            continue
        win = m1.iloc[max(0, i - 1000):i + 1]
        s1 = win.tail(400).reset_index(drop=True)
        s5 = resample(win, "5min").tail(400).reset_index(drop=True)
        s15 = resample(win, "15min").tail(400).reset_index(drop=True)
        sig = S.signal(s1, s5, s15, cfg)
        ok, _ = S.auto_gate(sig, cfg)
        if not ok:
            continue
        side = sig["side"]
        pos = b.positions()
        if len(pos) >= cfg.max_positions:
            continue
        price = b.ask if side == "buy" else b.bid
        if any(p.side == side and abs(p.entry - price) < cfg.entry_gap_atr * sig["atr"] for p in pos):
            continue
        lots, _ = lots_for(eq, price, sig["sl"], cfg, spec)
        if lots > 0:
            b.place(side, lots, sig["sl"], sig["tp"])
    b.close_all()
    tr = b.closed
    wins = [t for t in tr if t["pnl"] > 0]
    gp = sum(t["pnl"] for t in wins)
    gl = -sum(t["pnl"] for t in tr if t["pnl"] <= 0)
    peak, dd = balance, 0.0
    for e in curve:
        peak = max(peak, e)
        dd = max(dd, (peak - e) / peak * 100 if peak else 0)
    return dict(bars=len(m1), trades=len(tr), wins=len(wins),
                win_rate=round(len(wins) / len(tr) * 100, 1) if tr else 0.0,
                net=round(b.balance - balance, 2), start=balance, final=round(b.balance, 2),
                profit_factor=round(gp / gl, 2) if gl > 0 else (None if not tr else 99.0),
                max_drawdown_pct=round(float(dd), 1), halted=halted, target=target,
                curve=[round(x, 2) for x in curve[::max(1, len(curve) // 120)]])


if __name__ == "__main__":
    import argparse, json
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv"); ap.add_argument("--bars", type=int, default=3000)
    ap.add_argument("--balance", type=float); ap.add_argument("--target", type=float)
    a = ap.parse_args()
    m1 = load_csv(a.csv) if a.csv else make_sample_m1(a.bars)
    r = run_backtest(m1, Settings(), a.balance, a.target)
    r.pop("curve")
    print(json.dumps(r, indent=2))
    if not a.csv:
        print("NOTE: synthetic data. Use --csv with real broker XAUUSD M1 history for anything meaningful.")
