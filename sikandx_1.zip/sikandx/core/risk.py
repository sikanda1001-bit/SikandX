"""Position sizing that tells the truth about risk."""


def lots_for(equity: float, entry: float, sl: float, cfg, spec: dict):
    """Return (lots, reason). lots == 0 means: do not trade."""
    dist = abs(entry - sl)
    if dist <= 0:
        return 0.0, "Stop distance is zero."
    risk_cash = max(equity, 0.0) * cfg.risk_pct / 100.0
    contract = spec.get("contract", cfg.contract_size)
    raw = risk_cash / (dist * contract)
    step = spec.get("vol_step", 0.01) or 0.01
    lots = int(raw / step) * step
    vmin, vmax = spec.get("vol_min", 0.01), min(spec.get("vol_max", 100.0), cfg.max_lots)
    if lots < vmin:
        real_risk = vmin * dist * contract
        if real_risk > risk_cash * cfg.max_risk_overshoot:
            return 0.0, (f"Smallest lot ({vmin}) would risk {real_risk:.2f}, "
                         f"over {cfg.max_risk_overshoot:g}x your {risk_cash:.2f} limit. Trade skipped.")
        lots = vmin
    lots = min(lots, vmax)
    return round(lots, 2), ""
