"""Supply / demand zone detection: tight base + impulse leg, scored, deduped."""
import pandas as pd


def atr(df: pd.DataFrame, n: int = 14) -> pd.Series:
    pc = df["close"].shift(1)
    tr = pd.concat([df["high"] - df["low"], (df["high"] - pc).abs(), (df["low"] - pc).abs()], axis=1).max(axis=1)
    return tr.rolling(n, min_periods=3).mean()


def detect_zones(df: pd.DataFrame, cfg) -> list:
    n = len(df)
    if n < 40:
        return []
    a = atr(df).bfill().fillna(0.3).to_numpy()
    o, h, l, c = (df[k].to_numpy(float) for k in ("open", "high", "low", "close"))
    zones = []
    for i in range(15, n):
        ref = max(a[i - 1], 1e-6)
        body = c[i] - o[i]
        if abs(body) < cfg.impulse_atr * ref:
            continue
        base, bh, bl = [], -1e18, 1e18
        j = i - 1
        while j >= 0 and len(base) < cfg.base_max_bars and (h[j] - l[j]) <= cfg.base_bar_atr * a[j]:
            nh, nl = max(bh, h[j]), min(bl, l[j])
            if nh - nl > cfg.base_total_atr * ref:
                break
            bh, bl = nh, nl
            base.append(j)
            j -= 1
        if not base:
            continue
        body_hi = max(max(o[k], c[k]) for k in base)
        body_lo = min(min(o[k], c[k]) for k in base)
        if body > 0 and c[i] > bh:
            ztype, top, bottom = "demand", body_hi, bl
        elif body < 0 and c[i] < bl:
            ztype, top, bottom = "supply", bh, body_lo
        else:
            continue
        if top - bottom < 1e-6:
            continue
        touches, broken = 0, False
        for k in range(i + 1, n):
            if ztype == "demand":
                if c[k] < bottom:
                    broken = True
                    break
                if l[k] <= top:
                    touches += 1
            else:
                if c[k] > top:
                    broken = True
                    break
                if h[k] >= bottom:
                    touches += 1
        if broken or (n - i) > cfg.zone_expiry_bars:
            continue
        strength = min(30.0, abs(body) / ref * 10)
        fresh = 20 if touches == 0 else (10 if touches == 1 else 0)
        tight = 10 if (top - bottom) < 1.2 * ref else 0
        score = int(round(40 + strength + fresh + tight))
        zones.append(dict(type=ztype, top=float(top), bottom=float(bottom), index=int(i),
                          touches=int(touches), score=min(100, score)))
    zones.sort(key=lambda z: -z["score"])
    kept = []
    for z in zones:
        dup = False
        for k in kept:
            if k["type"] != z["type"]:
                continue
            ov = min(k["top"], z["top"]) - max(k["bottom"], z["bottom"])
            if ov > 0.5 * min(k["top"] - k["bottom"], z["top"] - z["bottom"]):
                dup = True
                break
        if not dup:
            kept.append(z)
    return kept


def zones_near_price(zones, price, tol):
    return [z for z in zones if z["bottom"] - tol <= price <= z["top"] + tol]


def nearest_opposing_zone(zones, price, side):
    if side == "buy":
        c = [z for z in zones if z["type"] == "supply" and z["bottom"] > price]
        return min(c, key=lambda z: z["bottom"]) if c else None
    c = [z for z in zones if z["type"] == "demand" and z["top"] < price]
    return max(c, key=lambda z: z["top"]) if c else None
