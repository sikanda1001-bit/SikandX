"""Plain-language command parser for the chat tab."""
import re

HELP = ("You can say: buy / sell (optionally with lots, e.g. 'buy 0.05'), close all, pause, resume, "
        "resume target 500, set target 500, max positions 3, min score 55, risk 0.5, auto on, auto off, "
        "scan, status, confirm live, revoke live.")


def _num(t):
    m = re.findall(r"\d+(?:\.\d+)?", t)
    return float(m[0]) if m else None


def parse(text: str) -> dict:
    t = (text or "").strip().lower()
    if not t:
        return dict(action="empty")
    n = _num(t)
    if "confirm live" in t: return dict(action="confirm_live")
    if "revoke live" in t: return dict(action="revoke_live")
    if re.search(r"close (all|everything)|flatten|exit all", t): return dict(action="close_all")
    if t.startswith("resume") or t.startswith("restart"): return dict(action="resume", target=n)
    if "pause" in t or "stop trading" in t: return dict(action="pause")
    if "target" in t:
        return dict(action="set_target", value=n) if n else dict(action="invalid", reply="Give a number, e.g. 'set target 500'.")
    if re.search(r"max.*position|positions? (limit|max)", t):
        return dict(action="set", key="max_positions", value=n) if n else dict(action="invalid", reply="Give a number, e.g. 'max positions 3'.")
    if "score" in t:
        return dict(action="set", key="min_score", value=n) if n is not None else dict(action="invalid", reply="Give a number, e.g. 'min score 55'.")
    if t.startswith("risk"):
        return dict(action="set", key="risk_pct", value=n) if n else dict(action="invalid", reply="Give a percent, e.g. 'risk 0.5'.")
    if "auto" in t:
        off = any(w in t for w in ("off", "disable", "stop"))
        return dict(action="auto", value=not off)
    if re.search(r"\b(status|balance|equity|account)\b", t): return dict(action="status")
    if re.search(r"\b(scan|signal|analy[sz]e|setup)\b", t): return dict(action="scan")
    if re.match(r"(buy|long)\b", t): return dict(action="trade", side="buy", lots=n)
    if re.match(r"(sell|short)\b", t): return dict(action="trade", side="sell", lots=n)
    if t in ("help", "?", "commands"): return dict(action="help")
    return dict(action="unknown")
