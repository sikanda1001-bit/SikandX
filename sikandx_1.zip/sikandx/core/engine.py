"""Engine: one background loop that watches the market, enforces protection, and (optionally) trades.

Safety rules baked in:
  * Protection (equity target, daily loss, retrying a failed close-all) runs EVERY cycle, auto or not.
  * Autonomous entries need the strategy gate. Manual chat orders are explicit overrides of direction only.
  * Live accounts need CONFIRM LIVE (re-required after every restart or broker change). Closing is never blocked.
  * Live/demo is read from the MT5 terminal. If MT5 candles fail, the engine skips the cycle; it never
    falls back to synthetic data while connected to a real broker.
"""
import threading, time, datetime as dt

from .config import Settings, Store
from .data import SampleFeed
from . import strategy as S
from .risk import lots_for
from .commands import parse, HELP
from .zones import atr
from brokers.paper import PaperBroker


class Engine:
    def __init__(self, cfg: Settings, store: Store):
        self.cfg, self.store = cfg, store
        self.lock = threading.RLock()
        self.feed = SampleFeed()
        self.broker = PaperBroker(cfg.paper_balance, cfg.contract_size, cfg.spread)
        self.paused = self.halted = self.auto = self.live_confirmed = False
        self.halt_reason = ""
        self.close_pending = False
        self.log, self.sig, self.chart = [], None, None
        self.last_entry = {}                 # side -> (epoch, price)
        self.day, self.day_start = None, None
        self.last_error = ""
        self.cycles = 0
        self._load()

    # ---------- persistence ----------
    def _load(self):
        b = self.store.load()
        self.cfg.update(b.get("settings", {}))
        self.paused = bool(b.get("paused", False))
        self.halted = bool(b.get("halted", False))
        self.halt_reason = b.get("halt_reason", "")
        self.broker.balance = self.broker.start = self.cfg.paper_balance
        if self.halted:
            self.say("system", f"Restored halted state: {self.halt_reason or 'halted'}. Say 'resume' when ready.")

    def save(self):
        self.store.save(dict(settings=self.cfg.public(), paused=self.paused,
                             halted=self.halted, halt_reason=self.halt_reason))

    def say(self, role, text):
        self.log.append(dict(role=role, text=str(text)[:700], t=dt.datetime.now().strftime("%H:%M:%S")))
        del self.log[:-80]

    # ---------- loop ----------
    def start(self):
        threading.Thread(target=self._loop, daemon=True, name="sikandx-engine").start()

    def _loop(self):
        while True:
            self.cycle()
            time.sleep(self.cfg.loop_seconds)

    def _frames(self):
        if self.broker.kind == "mt5":
            return self.broker.frames()                     # raises on failure: never substitute fake data
        return self.feed.frames()

    def cycle(self):
        with self.lock:
            try:
                if self.broker.kind == "paper":
                    self.broker.mark(self.feed.step())
                self.cycles += 1
                self._track_day()
                self._protect()
                m1, m5, m15 = self._frames()
                self.sig = S.signal(m1, m5, m15, self.cfg)
                self._build_chart(m5)
                self.last_error = ""
                if self.auto and not self.paused and not self.halted:
                    self._auto_entry()
            except Exception as e:
                msg = f"Cycle error: {e}"
                if msg != self.last_error:
                    self.say("system", msg)
                self.last_error = msg

    def _track_day(self):
        today = dt.date.today()
        if self.day != today:
            self.day = today
            self.day_start = self.broker.account().equity

    def _protect(self):
        acct = self.broker.account()
        if not self.halted:
            if acct.equity >= self.cfg.equity_target:
                self._halt(f"Equity target reached ({acct.equity:.2f} of {self.cfg.equity_target:.2f}).")
            elif self.cfg.daily_loss_pct > 0 and self.day_start and \
                    acct.equity <= self.day_start * (1 - self.cfg.daily_loss_pct / 100):
                self._halt(f"Daily loss limit hit ({self.cfg.daily_loss_pct:g}% below today's start).")
        if self.halted and (self.close_pending or self.broker.positions()):
            ok, msg = self.broker.close_all()
            self.close_pending = not ok
            if not ok:
                self.say("alert", f"Close-all FAILED, retrying next cycle: {msg}")

    def _halt(self, reason):
        self.halted, self.halt_reason, self.auto = True, reason, False
        ok, msg = self.broker.close_all()
        self.close_pending = not ok
        self.say("alert" if not ok else "bot",
                 f"{reason} Closing all positions and halting. " + (msg if ok else f"CLOSE FAILED: {msg}"))
        self.save()

    def _build_chart(self, m5):
        tail = m5.tail(120).reset_index(drop=True)
        off = len(m5) - len(tail)
        zones = []
        for z in (self.sig["an"]["M5"] or {}).get("zones", [])[:8]:
            zones.append(dict(type=z["type"], top=z["top"], bottom=z["bottom"],
                              start=max(0, z["index"] - off), score=z["score"]))
        self.chart = dict(
            candles=[[str(r.time), r.open, r.high, r.low, r.close] for r in tail.itertuples()],
            zones=zones)

    # ---------- entries ----------
    def _auto_entry(self):
        ok, why = S.auto_gate(self.sig, self.cfg)
        if not ok:
            return
        ok, msg = self._execute(self.sig["side"], None, "auto")
        self.say("bot", f"Auto {self.sig['side']} (score {self.sig['score']}): {msg}")

    def _execute(self, side, lots_req, origin):
        cfg, b = self.cfg, self.broker
        if self.paused: return False, "Trading is paused. Say 'resume'."
        if self.halted: return False, f"Halted: {self.halt_reason} Say 'resume' (optionally with a new target)."
        if not b.is_demo and not self.live_confirmed:
            return False, "Live account: type CONFIRM LIVE in Settings before any real order."
        sig = self.sig
        if sig is None or sig.get("price") is None:
            return False, "No market data yet."
        if origin == "auto":
            ok, why = S.auto_gate(sig, cfg)
            if not ok: return False, why
            if sig["side"] != side: return False, f"Strategy shows {sig['side']}, not {side}."
        positions = b.positions()
        if len(positions) >= cfg.max_positions:
            return False, f"Already {len(positions)} open (limit {cfg.max_positions})."
        bid, ask = b.tick()
        price = ask if side == "buy" else bid
        a = sig["atr"] or 0.5
        now = time.time()
        if origin == "auto":
            last = self.last_entry.get(side)
            if last and now - last[0] < cfg.cooldown_seconds:
                return False, "Cooling down after the last entry."
            if any(p.side == side and abs(p.entry - price) < cfg.entry_gap_atr * a for p in positions):
                return False, f"Too close to an open {side}."
        if sig["side"] == side and sig["sl"] and sig["tp"]:
            sl, tp = sig["sl"], sig["tp"]
        else:                                                    # manual override: ATR-based protection
            d = a * cfg.sl_atr_mult
            sl, tp = (price - d, price + d * cfg.min_rr) if side == "buy" else (price + d, price - d * cfg.min_rr)
        spec = b.spec()
        if lots_req:
            lots = max(spec["vol_min"], min(float(lots_req), cfg.max_lots, spec["vol_max"]))
        else:
            lots, why = lots_for(b.account().equity, price, sl, cfg, spec)
            if lots <= 0: return False, why
        ok, msg = b.place(side, lots, sl, tp, f"SikandX {origin}")
        if ok:
            self.last_entry[side] = (now, price)
        return ok, msg

    # ---------- user actions ----------
    def set_settings(self, d):
        with self.lock:
            changed = self.cfg.update(d)
            if "paper_balance" in changed and self.broker.kind == "paper" and not self.broker.positions():
                self.broker.balance = self.broker.start = self.cfg.paper_balance
            if "equity_target" in changed:
                self.halted = self.halted and self.broker.account().equity >= self.cfg.equity_target
            self.save()
            return changed

    def resume(self, target=None):
        with self.lock:
            if target:
                self.cfg.update({"equity_target": target})
            eq = self.broker.account().equity
            if eq >= self.cfg.equity_target:
                return f"Equity {eq:.2f} is already at or above the target {self.cfg.equity_target:.2f}. Set a higher target first."
            self.paused = self.halted = False
            self.halt_reason = ""
            self.day_start = eq
            self.save()
            return f"Resumed. Target {self.cfg.equity_target:.2f} is enforced on every cycle."

    def set_auto(self, on):
        with self.lock:
            if on and (self.halted or self.paused):
                return "Cannot enable auto while paused or halted. Say 'resume' first."
            self.auto = bool(on)
            return ("Auto mode on. Entries only fire when a scored zone plus break of structure or trendline "
                    "confirms, at or above your minimum score.") if on else "Auto mode off."

    def pause(self):
        with self.lock:
            self.paused, self.auto = True, False
            self.save()
            return "Paused. No new entries until 'resume'. Open positions keep their stops."

    def close_all(self):
        with self.lock:
            ok, msg = self.broker.close_all()
            return msg

    def confirm_live(self, typed):
        with self.lock:
            if self.broker.is_demo:
                return "This is a demo or paper account. No confirmation needed."
            if (typed or "").strip() != "CONFIRM LIVE":
                return "Type exactly CONFIRM LIVE to authorize real orders."
            self.live_confirmed = True
            return "Live trading authorized until you revoke it, restart, or change broker."

    def connect_mt5(self, login, password, server):
        from brokers.mt5 import MT5Broker
        with self.lock:
            nb = MT5Broker(self.cfg)
            ok, msg = nb.connect(login, password, server)
            if not ok:
                return False, msg
            self._swap(nb)
            return True, msg

    def disconnect(self):
        with self.lock:
            if self.broker.kind == "mt5":
                self.broker.disconnect()
            self._swap(PaperBroker(self.cfg.paper_balance, self.cfg.contract_size, self.cfg.spread))
            return "Disconnected. Back on the paper account."

    def _swap(self, nb):
        self.broker = nb
        self.auto = False
        self.live_confirmed = False
        self.last_entry = {}
        self.day = None
        self.sig = self.chart = None

    def scan(self):
        with self.lock:
            self.cycle_signal_only()
            return self.describe_signal()

    def cycle_signal_only(self):
        m1, m5, m15 = self._frames()
        self.sig = S.signal(m1, m5, m15, self.cfg)
        self._build_chart(m5)

    def describe_signal(self):
        s = self.sig
        if not s or s["price"] is None:
            return "No data yet."
        if not s["side"]:
            return f"No setup at {s['price']:.2f}. " + ("; ".join(s["reasons"][:3]) or "Waiting.")
        ok, why = S.auto_gate(s, self.cfg)
        return (f"{s['side'].upper()} setup, score {s['score']}, price {s['price']:.2f}, stop {s['sl']:.2f}, "
                f"target {s['tp']:.2f}. {'Auto-eligible' if ok else 'Not auto-eligible: ' + why}")

    # ---------- chat ----------
    def command(self, text):
        with self.lock:
            self.say("user", text if text.strip() else "(empty)")
            try:
                reply = self._apply(parse(text))
            except Exception as e:
                reply = f"Command failed: {e}"
            self.say("bot", reply)
            return reply

    def _apply(self, p):
        a = p["action"]
        if a == "empty": return "Type a command, or 'help'."
        if a in ("invalid",): return p["reply"]
        if a == "unknown" or a == "help": return HELP
        if a == "status":
            acct = self.broker.account()
            return (f"{self.broker.label}: balance {acct.balance:.2f}, equity {acct.equity:.2f}, "
                    f"{len(self.broker.positions())} open. Target {self.cfg.equity_target:.2f}. "
                    f"auto={self.auto} paused={self.paused} halted={self.halted}.")
        if a == "scan": self.cycle_signal_only(); return self.describe_signal()
        if a == "close_all": return self.close_all()
        if a == "pause": return self.pause()
        if a == "resume": return self.resume(p.get("target"))
        if a == "set_target":
            self.set_settings({"equity_target": p["value"]})
            return f"Target set to {self.cfg.equity_target:.2f} and saved."
        if a == "set":
            self.set_settings({p["key"]: p["value"]})
            return f"{p['key']} set to {getattr(self.cfg, p['key'])} and saved."
        if a == "auto": return self.set_auto(p["value"])
        if a == "confirm_live": return self.confirm_live("CONFIRM LIVE")
        if a == "revoke_live":
            self.live_confirmed = False
            return "Live authorization revoked."
        if a == "trade":
            ok, msg = self._execute(p["side"], p.get("lots"), "chat")
            return msg
        return "Unhandled command."

    # ---------- state for the app ----------
    def state(self):
        with self.lock:
            acct = self.broker.account()
            return dict(
                settings=self.cfg.public(),
                flags=dict(paused=self.paused, halted=self.halted, auto=self.auto,
                           live_confirmed=self.live_confirmed, halt_reason=self.halt_reason,
                           close_pending=self.close_pending),
                broker=dict(kind=self.broker.kind, label=self.broker.label, is_demo=self.broker.is_demo,
                            feed=("MT5 candles" if self.broker.kind == "mt5" else self.feed.label)),
                account=dict(balance=round(acct.balance, 2), equity=round(acct.equity, 2),
                             currency=acct.currency, day_start=round(self.day_start or acct.equity, 2)),
                positions=[p.public() for p in self.broker.positions()],
                signal=S.compact(self.sig) if self.sig else None,
                log=self.log[-40:], error=self.last_error, cycles=self.cycles)

    def chart_data(self):
        with self.lock:
            ch = dict(self.chart or dict(candles=[], zones=[]))
            ch["positions"] = [p.public() for p in self.broker.positions()]
            return ch
