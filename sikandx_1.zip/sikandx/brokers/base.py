from dataclasses import dataclass, field


@dataclass
class Position:
    ticket: int
    side: str
    lots: float
    entry: float
    sl: float
    tp: float
    profit: float = 0.0
    opened: str = ""

    def public(self):
        return dict(ticket=self.ticket, side=self.side, lots=self.lots, entry=round(self.entry, 2),
                    sl=round(self.sl, 2), tp=round(self.tp, 2), profit=round(self.profit, 2))


@dataclass
class Account:
    balance: float = 0.0
    equity: float = 0.0
    currency: str = "USD"
    login: str = ""
    server: str = ""


class Broker:
    kind = "base"
    is_demo = True
    label = "Broker"

    def account(self) -> Account: raise NotImplementedError
    def positions(self) -> list: raise NotImplementedError
    def tick(self): raise NotImplementedError          # (bid, ask)
    def spec(self) -> dict: raise NotImplementedError
    def place(self, side, lots, sl, tp, comment="SikandX"): raise NotImplementedError   # (ok, msg)
    def close_all(self): raise NotImplementedError     # (ok, msg)
