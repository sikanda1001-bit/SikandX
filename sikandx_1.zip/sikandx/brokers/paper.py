"""Paper broker: fills at bid/ask with spread, SL/TP checked on every bar (SL first if both hit)."""
import datetime as dt
from .base import Broker, Position, Account


class PaperBroker(Broker):
    kind = "paper"
    is_demo = True
    label = "Paper account"

    def __init__(self, balance: float, contract: float, spread: float):
        self.balance = float(balance)
        self.start = float(balance)
        self.contract, self.spread = contract, spread
        self._pos, self.closed = [], []
        self._next = 1
        self.bid = self.ask = 0.0

    def mark(self, bar: dict):
        s = self.spread
        self.bid, self.ask = bar["close"], bar["close"] + s
        for p in list(self._pos):
            if p.side == "buy":
                if p.sl and bar["low"] <= p.sl: self._close(p, p.sl, "SL")
                elif p.tp and bar["high"] >= p.tp: self._close(p, p.tp, "TP")
            else:
                if p.sl and bar["high"] + s >= p.sl: self._close(p, p.sl, "SL")
                elif p.tp and bar["low"] + s <= p.tp: self._close(p, p.tp, "TP")

    def _pnl(self, p, exit_price):
        d = (exit_price - p.entry) if p.side == "buy" else (p.entry - exit_price)
        return d * p.lots * self.contract

    def _close(self, p, price, why):
        pnl = self._pnl(p, price)
        self.balance += pnl
        self._pos.remove(p)
        self.closed.append(dict(ticket=p.ticket, side=p.side, lots=p.lots, entry=p.entry,
                                exit=price, pnl=pnl, reason=why))

    def _floating(self, p):
        return self._pnl(p, self.bid if p.side == "buy" else self.ask)

    def account(self):
        return Account(balance=self.balance, equity=self.balance + sum(self._floating(p) for p in self._pos),
                       currency="USD", login="paper", server="local")

    def positions(self):
        for p in self._pos:
            p.profit = self._floating(p)
        return list(self._pos)

    def tick(self): return self.bid, self.ask

    def spec(self):
        return dict(vol_min=0.01, vol_step=0.01, vol_max=100.0, contract=self.contract)

    def place(self, side, lots, sl, tp, comment="SikandX"):
        if self.bid <= 0:
            return False, "No price yet."
        px = self.ask if side == "buy" else self.bid
        p = Position(self._next, side, float(lots), float(px), float(sl), float(tp),
                     opened=dt.datetime.now().isoformat(timespec="seconds"))
        self._next += 1
        self._pos.append(p)
        return True, f"Paper {side} {lots} lots at {px:.2f}, stop {sl:.2f}, target {tp:.2f}."

    def close_all(self):
        n = len(self._pos)
        for p in list(self._pos):
            self._close(p, self.bid if p.side == "buy" else self.ask, "CLOSE")
        return True, f"Closed {n} position(s)." if n else "No open positions."
