"""MetaTrader 5 broker (Windows + MT5 terminal). Demo/live is read from the terminal, never from the user."""
from .base import Broker, Position, Account

MAGIC = 20260914


class MT5Broker(Broker):
    kind = "mt5"

    def __init__(self, cfg):
        self.cfg = cfg
        self.mt5 = None
        self.symbol = cfg.symbol
        self.is_demo = True
        self.label = "MT5"
        self._info = None

    # ---- connect ----
    def connect(self, login="", password="", server=""):
        try:
            import MetaTrader5 as mt5
        except Exception:
            return False, "MetaTrader5 package not found. It needs Windows and the MT5 terminal (pip install MetaTrader5)."
        if not mt5.initialize():
            return False, f"Could not start MT5: {mt5.last_error()}. Open the terminal and log in once."
        if str(login).strip().isdigit():
            if not mt5.login(int(login), password=password or "", server=server or ""):
                err = mt5.last_error()
                mt5.shutdown()
                return False, f"MT5 login failed for {login}: {err}"
        info = mt5.account_info()
        if info is None:
            mt5.shutdown()
            return False, f"MT5 account info unavailable: {mt5.last_error()}"
        real = getattr(mt5, "ACCOUNT_TRADE_MODE_REAL", 2)
        self.is_demo = info.trade_mode != real          # decided by the terminal, not the form
        for cand in (self.cfg.symbol,) + tuple(self.cfg.symbol_variants):
            si = mt5.symbol_info(cand)
            if si is not None:
                mt5.symbol_select(cand, True)
                self.symbol, self._info = cand, si
                break
        else:
            mt5.shutdown()
            return False, f"Gold symbol not found. Tried: {', '.join(self.cfg.symbol_variants)}."
        self.mt5 = mt5
        mode = "demo" if self.is_demo else "LIVE"
        self.label = f"MT5 {mode}"
        return True, f"MT5 connected: account {info.login} on {info.server}, {mode}, balance {info.balance:.2f} {info.currency}."

    def disconnect(self):
        try:
            if self.mt5: self.mt5.shutdown()
        except Exception:
            pass
        self.mt5 = None

    # ---- reads ----
    def account(self):
        i = self.mt5.account_info()
        if i is None:
            raise RuntimeError(f"account_info failed: {self.mt5.last_error()}")
        return Account(float(i.balance), float(i.equity), str(i.currency), str(i.login), str(i.server))

    def positions(self):
        out = []
        for p in (self.mt5.positions_get(symbol=self.symbol) or ()):
            out.append(Position(int(p.ticket), "buy" if p.type == 0 else "sell", float(p.volume),
                                float(p.price_open), float(p.sl or 0), float(p.tp or 0), float(p.profit or 0)))
        return out

    def tick(self):
        t = self.mt5.symbol_info_tick(self.symbol)
        if t is None:
            raise RuntimeError("No tick for " + self.symbol)
        return float(t.bid), float(t.ask)

    def spec(self):
        si = self.mt5.symbol_info(self.symbol) or self._info
        return dict(vol_min=si.volume_min, vol_step=si.volume_step, vol_max=si.volume_max,
                    contract=si.trade_contract_size)

    def frames(self, bars=400):
        import pandas as pd
        mt5, out = self.mt5, []
        for tf in (mt5.TIMEFRAME_M1, mt5.TIMEFRAME_M5, mt5.TIMEFRAME_M15):
            r = mt5.copy_rates_from_pos(self.symbol, tf, 1, bars)    # start at 1 = closed candles only
            if r is None or len(r) < 40:
                raise RuntimeError(f"MT5 returned too few candles: {mt5.last_error()}")
            df = pd.DataFrame(r)
            df["time"] = pd.to_datetime(df["time"], unit="s")
            out.append(df[["time", "open", "high", "low", "close"]])
        return tuple(out)

    # ---- writes ----
    def _send(self, req):
        """Try filling modes until the broker accepts one."""
        mt5 = self.mt5
        last = "no response"
        for fill in (mt5.ORDER_FILLING_IOC, mt5.ORDER_FILLING_FOK, mt5.ORDER_FILLING_RETURN):
            res = mt5.order_send({**req, "type_filling": fill})
            if res is None:
                last = str(mt5.last_error()); continue
            if res.retcode == mt5.TRADE_RETCODE_DONE:
                return True, res
            last = f"retcode {res.retcode} ({res.comment})"
            if res.retcode not in (10030, 10027):       # not a filling-mode problem: stop retrying
                break
        return False, last

    def place(self, side, lots, sl, tp, comment="SikandX"):
        mt5 = self.mt5
        try:
            t = mt5.symbol_info_tick(self.symbol)
            if t is None:
                return False, "No tick available."
            dg = self._info.digits
            req = dict(action=mt5.TRADE_ACTION_DEAL, symbol=self.symbol, volume=float(lots),
                       type=mt5.ORDER_TYPE_BUY if side == "buy" else mt5.ORDER_TYPE_SELL,
                       price=t.ask if side == "buy" else t.bid, sl=round(float(sl), dg), tp=round(float(tp), dg),
                       deviation=30, magic=MAGIC, comment=comment[:31], type_time=mt5.ORDER_TIME_GTC)
            ok, res = self._send(req)
            if not ok:
                return False, f"MT5 rejected the order: {res}"
            return True, f"MT5 {side} {lots} lots filled at {res.price:.2f} (ticket {res.order})."
        except Exception as e:
            return False, f"MT5 order error: {e}"

    def close_all(self):
        mt5 = self.mt5
        try:
            poss = mt5.positions_get(symbol=self.symbol) or ()
            if not poss:
                return True, "No open positions."
            n, fails = 0, []
            for p in poss:
                t = mt5.symbol_info_tick(p.symbol)
                if t is None:
                    fails.append(p.ticket); continue
                buy = p.type == 0
                ok, _ = self._send(dict(action=mt5.TRADE_ACTION_DEAL, symbol=p.symbol, volume=float(p.volume),
                                        type=mt5.ORDER_TYPE_SELL if buy else mt5.ORDER_TYPE_BUY,
                                        position=p.ticket, price=t.bid if buy else t.ask, deviation=30,
                                        magic=MAGIC, comment="SikandX close", type_time=mt5.ORDER_TIME_GTC))
                n += ok
                if not ok: fails.append(p.ticket)
            if fails:
                return False, f"Closed {n}; failed tickets {', '.join(map(str, fails))}."
            return True, f"Closed {n} position(s)."
        except Exception as e:
            return False, f"MT5 close error: {e}"
