"use strict";
/* SikandX client. Talks JSON to the server with a bearer token. No frameworks. */
const $ = (s, el = document) => el.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const money = n => (n ?? 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const cap = !!window.Capacitor;
const LS = {
  get url() { return (localStorage.getItem("sx_url") || (cap ? "" : location.origin)).replace(/\/$/, ""); },
  get token() { return localStorage.getItem("sx_token") || ""; },
  set(u, t) { localStorage.setItem("sx_url", u.replace(/\/$/, "")); localStorage.setItem("sx_token", t); },
  clear() { localStorage.removeItem("sx_token"); }
};
let S = null, tab = "home", poll = null, settingsFilled = false, chartData = null;

async function api(path, body) {
  const opt = { headers: { Authorization: "Bearer " + LS.token } };
  if (body !== undefined) { opt.method = "POST"; opt.headers["Content-Type"] = "application/json"; opt.body = JSON.stringify(body); }
  const r = await fetch(LS.url + "/api/" + path, opt);
  if (r.status === 401) { stop(); gate("That token was not accepted. Check it and try again."); throw new Error("auth"); }
  return r.json();
}
function toast(t) {
  const el = document.createElement("div"); el.className = "toast"; el.textContent = t; document.body.appendChild(el);
  setTimeout(() => el.remove(), 3200);
}
const stop = () => { clearInterval(poll); poll = null; };

/* ---------- connect screen ---------- */
function gate(msg) {
  stop();
  $("#app").innerHTML = `<div class="gate">
    <span class="brand">SikandX</span>
    <p>${esc(msg || "Connect to your SikandX server to start.")}</p>
    <label for="gu">Server address</label>
    <input id="gu" inputmode="url" autocapitalize="off" placeholder="https://your-server.example" value="${esc(LS.url)}">
    <label for="gt">Access token</label>
    <input id="gt" type="password" autocomplete="off" placeholder="Printed when the server starts">
    <div class="row"><button class="btn gold" id="go">Connect</button></div>
    <p class="note">The token stays on this device. Use an https address; the server holds your broker session.</p></div>`;
  $("#go").onclick = async () => {
    const u = $("#gu").value.trim() || location.origin, t = $("#gt").value.trim();
    if (!t) return toast("Enter the access token.");
    LS.set(u, t);
    try {
      const p = await (await fetch(u.replace(/\/$/, "") + "/api/ping")).json();
      if (!p.ok) throw 0;
      const r = await fetch(u.replace(/\/$/, "") + "/api/state", { headers: { Authorization: "Bearer " + t } });
      if (r.status === 401) return toast("Token not accepted.");
      boot();
    } catch { toast("Cannot reach the server at that address."); }
  };
}

/* ---------- shell ---------- */
function boot() {
  if (!LS.token || !LS.url) return gate();
  $("#app").innerHTML = `<div id="shell">
  <header><span class="brand">SikandX</span><span class="chip" id="chip"><i></i><span>Connecting</span></span></header>
  <main>
   <div class="view on" id="v-home">
    <div class="equity"><div class="eq-fig num" id="eq">–</div><div class="eq-sub num" id="eqsub"></div>
      <div class="goal"><div class="track"><div class="fill" id="gfill"></div><div class="dot" id="gdot"></div></div>
      <div class="meta"><span id="gpct"></span><span id="gtar"></span></div></div></div>
    <div id="banner"></div>
    <div class="controls"><button class="btn" id="bAuto">Auto</button><button class="btn" id="bPause">Pause</button><button class="btn ghost" id="bClose">Close all</button></div>
    <section><h2>Setup</h2><div class="card" id="sig"></div></section>
    <section><h2>Open positions</h2><div id="pos"></div></section>
   </div>
   <div class="view" id="v-chart"><h2>XAUUSD, 5 minute</h2><div id="chartWrap"><canvas id="chart"></canvas></div>
    <div class="legend"><span><i style="background:#d4af37"></i>Demand zone</span><span><i style="background:#fff"></i>Supply zone</span><span>Lines: your entries, stops and targets</span></div></div>
   <div class="view" id="v-chat"><div class="log" id="log"></div>
    <div class="quick"><button class="btn" data-q="status">Status</button><button class="btn" data-q="scan">Scan</button><button class="btn" data-q="buy">Buy</button><button class="btn" data-q="sell">Sell</button><button class="btn" data-q="help">Help</button></div>
    <div class="send"><input id="cin" placeholder="Tell SikandX what to do" autocomplete="off" enterkeyhint="send"><button class="btn gold" id="csend" style="flex:0 0 78px">Send</button></div></div>
   <div class="view" id="v-set">${settingsHTML()}</div>
  </main>
  <nav><button data-t="home" class="on">Home</button><button data-t="chart">Chart</button><button data-t="chat">Chat</button><button data-t="set">Settings</button></nav></div>`;
  document.querySelectorAll("nav button").forEach(b => b.onclick = () => show(b.dataset.t));
  $("#bAuto").onclick = () => act("auto", { on: !S.flags.auto });
  $("#bPause").onclick = () => S.flags.paused || S.flags.halted ? act("resume", {}) : act("pause", {});
  $("#bClose").onclick = () => confirm("Close every open XAUUSD position now?") && act("close-all", {});
  $("#csend").onclick = sendChat;
  $("#cin").onkeydown = e => e.key === "Enter" && sendChat();
  document.querySelectorAll("[data-q]").forEach(b => b.onclick = () => chat(b.dataset.q));
  wireSettings();
  refresh(); poll = setInterval(() => { if (!document.hidden) { refresh(); if (tab === "chart") loadChart(); } }, 3000);
}
function show(t) {
  tab = t;
  document.querySelectorAll(".view").forEach(v => v.classList.toggle("on", v.id === "v-" + t));
  document.querySelectorAll("nav button").forEach(b => b.classList.toggle("on", b.dataset.t === t));
  if (t === "chart") loadChart();
  if (t === "chat") { const l = $("#log"); l.parentElement.scrollTop = l.parentElement.scrollHeight; }
}
async function act(path, body) {
  try { const r = await api(path, body); if (r.reply) toast(r.reply); } catch (e) { if (e.message !== "auth") toast("Request failed."); }
  refresh();
}

/* ---------- state ---------- */
async function refresh() {
  try { S = await api("state"); } catch { return setChip("Offline", ""); }
  renderHome(); renderLog(); fillSettings();
}
function setChip(text, cls) { const c = $("#chip"); if (!c) return; c.className = "chip " + cls; c.lastChild.textContent = text; }
function renderHome() {
  const a = S.account, f = S.flags, st = S.settings, b = S.broker;
  setChip(b.is_demo ? b.label : "Live account", b.is_demo ? "ok" : "live");
  $("#eq").textContent = money(a.equity);
  const open = S.positions.reduce((x, p) => x + p.profit, 0);
  $("#eqsub").textContent = `Balance ${money(a.balance)}  |  Open ${open >= 0 ? "+" : "-"}${money(Math.abs(open))}  |  ${b.feed}`;
  const base = Math.min(a.day_start, a.equity), pct = Math.max(0, Math.min(100, (a.equity - base) / Math.max(st.equity_target - base, 0.01) * 100));
  $("#gfill").style.width = pct + "%"; $("#gdot").style.left = pct + "%";
  $("#gpct").innerHTML = `<b>${pct.toFixed(0)}%</b> toward target`;
  $("#gtar").innerHTML = `Target <b>${money(st.equity_target)}</b>`;
  let ban = "";
  if (f.halted) ban = `<div class="banner"><p>${esc(f.halt_reason || "Halted.")} No new trades until you resume.${f.close_pending ? " Closing positions failed and is being retried." : ""}</p><div class="row" style="margin:0"><input id="nt" inputmode="decimal" placeholder="New target (optional)"><button class="btn gold" id="rs" style="flex:0 0 100px">Resume</button></div></div>`;
  else if (S.error) ban = `<div class="banner err"><p>${esc(S.error)}</p></div>`;
  if ($("#banner").dataset.k !== ban) { const keep = $("#nt")?.value; $("#banner").innerHTML = ban; $("#banner").dataset.k = ban; if ($("#rs")) { if (keep) $("#nt").value = keep; $("#rs").onclick = () => act("resume", { target: parseFloat($("#nt").value) || null }); } }
  const au = $("#bAuto"); au.classList.toggle("on", f.auto); au.textContent = f.auto ? "Auto on" : "Auto off";
  $("#bPause").textContent = f.halted || f.paused ? "Resume" : "Pause";
  renderSignal(); renderPos();
}
function renderSignal() {
  const s = S.signal, el = $("#sig");
  if (!s || s.price == null) { el.innerHTML = `<div class="empty">Waiting for the first scan.</div>`; return; }
  const side = s.side, name = side === "buy" ? "Buy setup" : side === "sell" ? "Sell setup" : "No setup";
  const elig = side ? (s.score >= S.settings.min_score && s.gate.zone && s.gate.confirm
    ? ["yes", "Auto can take this: scored zone and confirmation both present."]
    : ["", `Auto will skip this: ${!s.gate.zone ? "not inside a scored zone" : !s.gate.confirm ? "no break of structure or trendline yet" : "score too low"}.`]) : ["", "Auto waits for a zone plus confirmation."];
  const why = s.reasons.length ? `<ul class="why">${s.reasons.map(r => `<li>${esc(r)}</li>`).join("")}</ul>` : "";
  const m = (k, lab) => { const v = s.bias[k]; const w = Math.abs(v.score) / 2; return `<div class="mrow"><span>${lab}</span><div class="mtrack"><div class="mbar ${v.score >= 0 ? "d" : "s"}" style="width:${w}%"></div></div><span class="mlab">${esc(v.label)}</span></div>`; };
  el.innerHTML = `<div class="sig-head"><span class="sig-side ${side || "none"}">${name}</span><span class="sig-score">Score <b class="num">${s.score}</b> of 100</span></div>
   <div class="num" style="color:var(--muted)">Gold at ${money(s.price)}</div>
   ${side ? `<div class="levels num"><span>Stop <b>${money(s.sl)}</b></span><span>Target <b>${money(s.tp)}</b></span></div>` : ""}${why}
   <div class="elig ${elig[0]}">${elig[1]}</div>
   <div class="meter"><div class="mscale"><div><span>Supply</span><span>Demand</span></div></div>${m("M1", "M1")}${m("M5", "M5")}${m("M15", "M15")}${m("total", "All")}</div>`;
}
function renderPos() {
  const p = S.positions, el = $("#pos");
  el.innerHTML = p.length ? `<div class="card" style="padding:4px 16px">${p.map(x => `<div class="pos"><span class="s ${x.side}">${x.side === "buy" ? "Buy" : "Sell"} ${x.lots}</span><span class="pl num ${x.profit >= 0 ? "up" : ""}">${x.profit >= 0 ? "+" : "-"}${money(Math.abs(x.profit))}</span><small class="num">Entry ${money(x.entry)}</small><small class="num" style="text-align:right">Stop ${money(x.sl)}  Target ${money(x.tp)}</small></div>`).join("")}</div>`
    : `<div class="empty">Nothing open. The bot is watching for a setup.</div>`;
}

/* ---------- chat ---------- */
let lastLog = "";
function renderLog() {
  const key = JSON.stringify(S.log.slice(-1)) + S.log.length;
  if (key === lastLog) return; lastLog = key;
  const box = $("#log"), parent = box.parentElement, atEnd = parent.scrollHeight - parent.scrollTop - parent.clientHeight < 80;
  box.innerHTML = S.log.length ? S.log.map(m => `<div class="msg ${m.role}">${esc(m.text)}<time>${esc(m.t)}</time></div>`).join("") : `<div class="empty">Say "help" to see what I understand.</div>`;
  if (atEnd) parent.scrollTop = parent.scrollHeight;
}
async function chat(text) { try { await api("command", { text }); } catch { } await refresh(); }
async function sendChat() { const i = $("#cin"), t = i.value.trim(); if (!t) return; i.value = ""; await chat(t); }

/* ---------- chart ---------- */
async function loadChart() { try { chartData = await api("chart"); drawChart(); } catch { } }
function drawChart() {
  const cv = $("#chart"); if (!cv || !chartData) return;
  const dpr = window.devicePixelRatio || 1, W = cv.clientWidth, H = cv.clientHeight;
  cv.width = W * dpr; cv.height = H * dpr;
  const g = cv.getContext("2d"); g.scale(dpr, dpr); g.clearRect(0, 0, W, H);
  const c = chartData.candles; if (!c.length) { g.fillStyle = "#a3a3a3"; g.fillText("Waiting for candles…", 16, 28); return; }
  const padR = 58, padT = 10, padB = 10, n = c.length, cw = (W - padR - 6) / n;
  let lo = Math.min(...c.map(x => x[3])), hi = Math.max(...c.map(x => x[2]));
  const span = hi - lo, ext = [lo - span * .15, hi + span * .15]; lo = ext[0]; hi = ext[1];
  const Y = v => padT + (hi - v) / (hi - lo) * (H - padT - padB), X = i => 4 + i * cw + cw / 2;
  g.font = "11px system-ui"; g.textBaseline = "middle";
  for (let k = 0; k <= 4; k++) {
    const v = lo + (hi - lo) * k / 4, y = Y(v);
    g.strokeStyle = "#1c1c1c"; g.beginPath(); g.moveTo(0, y); g.lineTo(W - padR, y); g.stroke();
    g.fillStyle = "#a3a3a3"; g.fillText(v.toFixed(1), W - padR + 6, y);
  }
  for (const z of chartData.zones) {
    const y1 = Y(Math.min(z.top, hi)), y2 = Y(Math.max(z.bottom, lo)); if (y2 < padT || y1 > H) continue;
    const d = z.type === "demand";
    g.fillStyle = d ? "rgba(212,175,55,.16)" : "rgba(255,255,255,.10)";
    g.fillRect(X(z.start), y1, W - padR - X(z.start), Math.max(2, y2 - y1));
    g.strokeStyle = d ? "rgba(212,175,55,.7)" : "rgba(255,255,255,.55)"; g.lineWidth = 1;
    g.beginPath(); g.moveTo(X(z.start), y1); g.lineTo(W - padR, y1); g.stroke();
  }
  c.forEach((x, i) => {
    const up = x[4] >= x[1], col = up ? "#d4af37" : "#ffffff";
    g.strokeStyle = col; g.fillStyle = col; g.lineWidth = 1;
    g.beginPath(); g.moveTo(X(i), Y(x[2])); g.lineTo(X(i), Y(x[3])); g.stroke();
    const yo = Y(x[1]), yc = Y(x[4]), bw = Math.max(1.5, cw * .66);
    if (up) g.fillRect(X(i) - bw / 2, Math.min(yo, yc), bw, Math.max(1, Math.abs(yc - yo)));
    else g.fillRect(X(i) - bw / 2, Math.min(yo, yc), bw, Math.max(1, Math.abs(yc - yo)));
  });
  const line = (v, col, dash, label) => {
    if (v < lo || v > hi) return; const y = Y(v);
    g.setLineDash(dash); g.strokeStyle = col; g.beginPath(); g.moveTo(0, y); g.lineTo(W - padR, y); g.stroke(); g.setLineDash([]);
    g.fillStyle = col; g.fillText(label, W - padR + 6, y);
  };
  for (const p of chartData.positions) {
    line(p.entry, "#f0d77a", [], (p.side === "buy" ? "Buy " : "Sell ") + p.entry.toFixed(1));
    if (p.sl) line(p.sl, "#a3a3a3", [5, 4], "SL"); if (p.tp) line(p.tp, "#d4af37", [5, 4], "TP");
  }
  const last = c[n - 1][4]; g.fillStyle = "#d4af37"; g.fillRect(W - padR, Y(last) - 9, padR, 18);
  g.fillStyle = "#000"; g.fillText(last.toFixed(2), W - padR + 5, Y(last));
}
window.addEventListener("resize", () => tab === "chart" && drawChart());

/* ---------- settings ---------- */
function settingsHTML() {
  const f = (id, lab, hint) => `<div><label for="${id}">${lab}</label><input id="${id}" inputmode="decimal"></div>`;
  return `<section><h2>Protection and entries</h2><div class="card"><div class="grid2">
   ${f("s_equity_target", "Equity target")}${f("s_max_positions", "Max open trades")}
   ${f("s_min_score", "Minimum score")}${f("s_risk_pct", "Risk per trade %")}
   ${f("s_daily_loss_pct", "Daily loss limit %")}${f("s_max_lots", "Max lot size")}
   ${f("s_paper_balance", "Paper balance")}${f("s_loop_seconds", "Scan every (sec)")}</div>
   <div class="row"><button class="btn gold" id="saveSet">Save</button></div>
   <p class="note">Reaching the target closes everything and stops new trades until you resume. The daily loss limit does the same on the way down. Both are checked every scan, even with auto off.</p></div></section>
  <section><h2>Broker</h2><div class="card"><div id="brokerNow" class="note" style="margin:0 0 6px"></div>
   <label for="m_login">MT5 login</label><input id="m_login" inputmode="numeric" autocomplete="off">
   <label for="m_pass">Password</label><input id="m_pass" type="password" autocomplete="off">
   <label for="m_server">Server</label><input id="m_server" autocomplete="off" placeholder="e.g. YourBroker-Demo">
   <div class="row"><button class="btn gold" id="mConnect">Connect MT5</button><button class="btn ghost" id="mDisc">Disconnect</button></div>
   <p class="note">MT5 runs on the Windows machine hosting the server. Whether the account is demo or live is read from the terminal, not from this form. Your password is kept in memory only.</p></div></section>
  <section id="liveSec"><h2>Live trading</h2><div class="card">
   <p class="note" style="margin:0 0 8px">Real orders on a live account need one-time authorization. It resets whenever the server restarts or the broker changes.</p>
   <label for="l_text">Type CONFIRM LIVE</label><input id="l_text" autocomplete="off">
   <div class="row"><button class="btn gold" id="lOn">Authorize</button><button class="btn ghost" id="lOff">Revoke</button></div></div></section>
  <section><h2>Backtest</h2><div class="card"><label for="b_bars">History length</label>
   <select id="b_bars"><option value="2000">2,000 candles</option><option value="3000" selected>3,000 candles</option><option value="5000">5,000 candles</option></select>
   <div class="row"><button class="btn gold" id="bRun">Run backtest</button></div><div id="bOut"></div>
   <p class="note">This uses generated sample prices, so it checks that the machinery works, not that the strategy makes money. Test real broker history before trusting it.</p></div></section>
  <section><h2>This device</h2><div class="card"><div class="note" style="margin:0 0 10px">Server: ${esc(LS.url)}</div><div class="row" style="margin-top:0"><button class="btn ghost" id="signOut">Sign out</button></div></div></section>`;
}
function fillSettings() {
  const st = S.settings;
  if (!settingsFilled) { for (const k in st) { const e = $("#s_" + k); if (e) e.value = st[k]; } settingsFilled = true; }
  $("#brokerNow").textContent = `Connected to: ${S.broker.label}. Candles: ${S.broker.feed}.`;
  $("#liveSec").style.display = S.broker.is_demo ? "none" : "";
}
function wireSettings() {
  settingsFilled = false;
  $("#saveSet").onclick = async () => {
    const d = {}; document.querySelectorAll("[id^=s_]").forEach(e => d[e.id.slice(2)] = e.value);
    await api("settings", d); toast("Saved."); refresh();
  };
  $("#mConnect").onclick = async () => {
    toast("Connecting…");
    const r = await api("connect", { login: $("#m_login").value, password: $("#m_pass").value, server: $("#m_server").value });
    $("#m_pass").value = ""; toast(r.reply || r.error); refresh();
  };
  $("#mDisc").onclick = () => act("disconnect", {});
  $("#lOn").onclick = async () => { await act("confirm-live", { text: $("#l_text").value }); $("#l_text").value = ""; };
  $("#lOff").onclick = () => act("revoke-live", {});
  $("#signOut").onclick = () => { LS.clear(); gate("Signed out."); };
  $("#bRun").onclick = async () => {
    $("#bOut").innerHTML = `<p class="note">Running… this can take up to a minute.</p>`; $("#bRun").disabled = true;
    try {
      const r = await api("backtest", { bars: +$("#b_bars").value }); $("#bRun").disabled = false;
      if (!r.ok) return $("#bOut").innerHTML = `<p class="note">${esc(r.error)}</p>`;
      $("#bOut").innerHTML = `<div class="result"><div>Trades<b class="num">${r.trades}</b></div><div>Win rate<b class="num">${r.win_rate}%</b></div>
       <div>Net result<b class="num ${r.net >= 0 ? "up" : ""}">${r.net >= 0 ? "+" : "-"}${money(Math.abs(r.net))}</b></div><div>Max drawdown<b class="num">${r.max_drawdown_pct}%</b></div>
       <div>Profit factor<b class="num">${r.profit_factor ?? "n/a"}</b></div><div>Final balance<b class="num">${money(r.final)}</b></div></div>`;
    } catch { $("#bRun").disabled = false; }
  };
}

/* ---------- start ---------- */
if ("serviceWorker" in navigator && !cap && location.protocol.startsWith("http")) navigator.serviceWorker.register("sw.js").catch(() => { });
boot();
